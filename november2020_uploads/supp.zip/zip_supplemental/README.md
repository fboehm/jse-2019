# Supplementary materials for JSE submission

## Student presentations and thesis

1. Project_Poster.pdf
1. report.pdf
2. user2016boehm.pdf
3. warfdiscovery2016boehm.tiff

## Code

1. Rmd/tweets.Rmd
2. Rmd/tweets-one.Rmd

## Data

1. analyzed tweets files: 
  a. data/2020-05-24-analyzed-tweet-ids.csv
  b. data/2020-05-25-analyzed-tweet-ids.csv
  c. data/2020-05-26-analyzed-tweet-ids.csv
2. data/tweets-data-dictionary.csv


